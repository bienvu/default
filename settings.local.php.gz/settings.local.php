<?php 
$databases = array (
  'default' => 
  array (
    'default' => 
    array (
      'database' => 'default',
      'username' => 'user',
      'password' => 'user',
      'host' => 'db',
      'port' => '',
      'driver' => 'mysql',
      'prefix' => '',
    ),
  ),
);
